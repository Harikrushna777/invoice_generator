import 'dart:io';

class Global {
  static bool isGrid = false;
  static bool isDark = false;

  static String? name;
  static String? email;
  static int? contact;
  static String? address;
  static File? image;
}
