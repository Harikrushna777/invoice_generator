class MyRoutes {
  static String home = '/';
  static String splash_screen = 'splash_screen';
  static String product_intro_page = 'product_intro_page';
  static String cart_page = 'cart_page';
  static String favourite_page = 'favourite_product';
  static String bill_pdf_page = 'bill_pdf_page';
  static String user_detail = 'user_detail';
}
